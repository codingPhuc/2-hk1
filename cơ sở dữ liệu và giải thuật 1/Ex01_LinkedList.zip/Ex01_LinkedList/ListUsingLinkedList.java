import java.util.NoSuchElementException;

public class ListUsingLinkedList<E>
        implements ListInterface<E> {
    Node<E> head;
    private int numNode;

    public ListUsingLinkedList() {
        head = null;
        numNode = 0;
    }

    @Override
    public int size() {
        return numNode;
    }

    @Override
    public boolean isEmpty() {
        // return numNode == 0;
        return head == null;
    }

    @Override
    public void addFirst(E item) {
    //    if (isEmpty()) {
    //         head = new Node<>(item, null);
    //    } else {
    //         Node<E> n = new Node<>(item, head);
    //         head = n;
    //    }
        head = new Node<>(item, head);
        numNode++;
    }

    @Override
    public void addLast(E item) {
        
    } 

    @Override
    public E removeFirst() throws NoSuchElementException {
        if (isEmpty()) {
            throw new NoSuchElementException("Empty list");
        }

        E item = head.getData();
        head = head.getNext();
        numNode--;
        return item;
    }

    @Override
    public E removeLast() throws NoSuchElementException {
        if (! isEmpty()) {
            return null;
        }
        Node<E> p = null, n = head;
        while (n.getNext() != null) {
            p = n;
            n = n.getNext();
        }

        E tmp = n.getData();
        if (p != null) {
            p.setNext(null);
        } else {
            head = null;
        }
        numNode--;

        return tmp;
    }

    @Override
    public boolean contains(E item) {
        Node<E> n = head;
        while (n != null) {
            if (n.getData().equals(item)) {
                return true;
            }
            n = n.getNext();
        }
        return false;
    }

    @Override
    public E getFirst() {
        // if (! isEmpty()) {
        //     return head.getData();
        // }
        // return null;

        return isEmpty()? head.getData(): null;
    }

    @Override
    public E getLast() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void print() {
        System.out.print("[");
        // for(Node<E> n = head; 
        //     n != null;
        //     n = n.getNext()) {

        //     System.out.print(n.getData() + ", ");
        // }
        Node<E> n = head;
        while (n != null) {
            System.out.print(n.getData() + ", ");
            n = n.getNext();
        }

        System.out.println("]");
        
    }

    @Override
    public void addAfter(Node<E> curr, E item) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public E removeAfter(Node<E> curr) throws NoSuchElementException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public E removeAt(int i) throws NoSuchElementException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public E getAt(int i) {
        // TODO Auto-generated method stub
        return null;
    }
}
