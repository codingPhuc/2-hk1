import java.util.Random;

public class TestListUsingLinkedList {
    public static void main(String[] args) {
        ListUsingLinkedList<Integer> list = new ListUsingLinkedList<>();
        Random rand = new Random();

        System.out.println("# Add");
        for (int i = 0; i < 10; i++) {
            list.addFirst(rand.nextInt() % 100);
        }
        list.print();

        System.out.println("# Remove");
        for (int i = 0; i < 5; i += 2) {
            System.out.print("Remove at " + i + ": ");
            System.out.println(list.removeAt(i));
        }
        list.print();

        System.out.println("# Search");
        System.out.println("Last: " + list.getLast());
        System.out.println("First:" + list.getFirst());
        System.out.println("At 3: " + list.getAt(3));
    }
}